# NIN Slip Arranger Pro

## Upload to GitHub
Upload the contents of this folder (not the ZIP itself) to the root of your GitHub repository.

## Build APK
After upload, open the repository's **Actions** tab, choose **Build Android APK**, tap **Run workflow** (or let the first push start the workflow), then download the artifact named `NIN-Slip-Arranger-Pro-debug-apk`.

## Important testing note
This is an initial build. The current processor assumes one tall page contains one front/back pair, with the back in the lower half and upside down. It crops outer near-white space and fits the pair into a 2-by-2 A4 layout. Test with copies of sample PDFs before using it for important printing. If your PDFs contain a different layout or multiple pairs on one page, the splitting logic must be adjusted. A4 output is borderless in the PDF canvas, but a physical printer may still add margins.


Android saving note: after creating the PDF, the app opens the Android share/save sheet. Choose Files (or Save to device), then select Downloads as the destination. The app does not claim the PDF is saved until the Android share sheet has been opened.
